#!/usr/bin/env python3
# ============================================================
#  ApniBari — one-command launcher for BOTH tiers
#
#     python3 start.py
#
#  tier 1 (frontend) : frontend/server.py  → UI on :3000 + /api proxy
#  tier 2 (backend)  : backend/app.py      → JSON API on :8001
#
#  They are separate programs — you can also run them apart:
#     python3 backend/app.py          # API only
#     python3 frontend/server.py      # UI only (needs backend up)
# ============================================================

import os
import sys
import threading
import time
import socket
import urllib.request

BASE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE)
sys.path.insert(0, os.path.join(BASE, "backend"))
sys.path.insert(0, os.path.join(BASE, "frontend"))


def wait_up(host, port, path, tries=40):
    url = f"http://{host}:{port}{path}"
    for _ in range(tries):
        try:
            with urllib.request.urlopen(url, timeout=1.5) as r:
                if r.status == 200:
                    return True
        except Exception:
            time.sleep(0.25)
    return False


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip if ip and not ip.startswith("127.") else "127.0.0.1"
    except Exception:
        return "127.0.0.1"


def main():
    from backend import app as backend_app
    from frontend import server as frontend_server

    print("""
  🟢 ApniBari (अपनी बारी) — Your Turn. Without the Wait.
     Two-tier architecture:  UI (:3000)  ──/api/*──▶  JSON API (:8001)
""", flush=True)

    tb = threading.Thread(target=backend_app.serve, daemon=True)
    tf = threading.Thread(target=frontend_server.serve, daemon=True)
    tb.start()
    tf.start()

    ok_api = wait_up("127.0.0.1", 8001, "/api/health")
    ok_ui = wait_up("127.0.0.1", 3000, "/api/health")   # proxied through the UI tier
    lan = lan_ip()

    if ok_api and ok_ui:
        print(f"""
     ✅ both tiers up
        On this device : http://localhost:3000/
        On your phone  : http://{lan}:3000/     (same Wi-Fi)
        Backend direct : http://localhost:8001/api/health   (raw JSON, no UI)
        ------------------------------------
        Landing : /        Patient demo : /demo
        TV      : /tv      API          : /api/health
""", flush=True)
    else:
        print(f"     ⚠ tiers: backend={'up' if ok_api else 'DOWN'} "
              f"frontend={'up' if ok_ui else 'DOWN'} — check ports 3000/8001", flush=True)

    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        print("\n  ApniBari stopped.", flush=True)


if __name__ == "__main__":
    main()
