/* ============================================================
   ApniBari — motion layer (v5 · Premium Glass)
   - scroll reveals (IntersectionObserver, staggered)
   - animated stat counters (Indian comma grouping)
   - respects prefers-reduced-motion
   Zero dependencies. Auto-tags common blocks; elements stay
   visible if this script never runs (no-JS safe).
   ============================================================ */

(function () {
  "use strict";

  var reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------- 1. tag blocks for reveal ---------- */
  var SELECTOR = [
    ".section-head",
    ".step-card", ".feat-card", ".cost-card", ".stat",
    ".photo-frame", ".panel", ".fact-strip", ".compare-wrap",
    ".gov-band", ".hero-grid > div", ".big-cta .container > *",
    ".basecard", ".flowbar"
  ].join(",");

  var targets = Array.prototype.slice.call(document.querySelectorAll(SELECTOR));
  if (!targets.length) return;

  targets.forEach(function (el, i) {
    el.classList.add("reveal");
    // wave stagger inside a group: index within its parent
    var sibs = el.parentElement
      ? Array.prototype.filter.call(el.parentElement.children, function (c) {
          return c.classList && c.classList.contains("reveal");
        })
      : [];
    var idx = sibs.indexOf(el);
    el.style.setProperty("--d", (reduced ? 0 : Math.min((idx >= 0 ? idx : i % 6) * 80, 420)) + "ms");
  });

  /* ---------- 2. reveal on scroll ---------- */
  if (!reduced && "IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) {
          en.target.classList.add("in");
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.1, rootMargin: "0px 0px -36px 0px" });
    targets.forEach(function (el) { io.observe(el); });
  } else {
    targets.forEach(function (el) { el.classList.add("in"); });
  }

  /* ---------- 3. animated counters ---------- */
  function parseStat(txt) {
    var m = txt.match(/^([^\d]*)([\d,]+(?:\.\d+)?)(.*)$/);
    if (!m) return null;
    return {
      pre: m[1],
      num: parseFloat(m[2].replace(/,/g, "")),
      suf: m[3],
      grouped: /,/.test(m[2])
    };
  }
  function fmt(n, grouped) {
    n = Math.round(n);
    return grouped ? n.toLocaleString("en-IN") : String(n);
  }

  var nums = Array.prototype.slice.call(document.querySelectorAll(".stat-num, .qsnap-now .v"));
  if (!reduced && "IntersectionObserver" in window && nums.length) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        cio.unobserve(en.target);
        var el = en.target;
        var p = parseStat(el.textContent);
        if (!p || !isFinite(p.num) || p.num === 0) return;   // "₹0" stays put
        var dur = 1500;
        var t0 = performance.now();
        (function tick(t) {
          var k = Math.min(1, (t - t0) / dur);
          var e = 1 - Math.pow(1 - k, 3);                    // ease-out cubic
          el.textContent = p.pre + fmt(p.num * e, p.grouped) + p.suf;
          if (k < 1) requestAnimationFrame(tick);
        })(t0);
      });
    }, { threshold: 0.6 });
    nums.forEach(function (el) { cio.observe(el); });
  }
})();
