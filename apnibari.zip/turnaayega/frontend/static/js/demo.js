/* ============================================================
   ApniBari — Patient demo logic
   PIN locator → hospital+doctor list → missed call → token →
   live queue polling → PM-JAY
   Talks ONLY to the frontend proxy (/api/* → backend :8001).
   ============================================================ */

let hospitals = [];          // last loaded (nearby-sorted) list
let selectedId = null;
let myToken = null;          // {number, code}
let pollTimer = null;
let calling = false;
let currentPin = null;

const $ = (id) => document.getElementById(id);

// ---------- PIN code locator ----------
async function loadPincodes() {
  try {
    const d = await TA.get('/api/pincodes');
    $('pinList').innerHTML = (d.pincodes || [])
      .map(p => `<option value="${p.pin}">${p.area}</option>`).join('');
  } catch (e) { /* suggestions are optional */ }
}

async function findNearby(pin, { silent = false } = {}) {
  pin = (pin || '').replace(/\D/g, '').slice(0, 6);
  if (pin.length !== 6) {
    $('pinStatus').className = 'pin-status err';
    $('pinStatus').textContent = 'Enter a full 6-digit PIN code.';
    return;
  }
  currentPin = pin;
  $('pinInput').value = pin;
  if (!silent) $('pinStatus').className = 'pin-status';
  if (!silent) $('pinStatus').textContent = 'Locating centres near ' + pin + '…';

  try {
    const d = await TA.get('/api/nearby?pin=' + pin);
    hospitals = d.hospitals || [];
    renderHospitals(d.recommendedId);
    renderHamdard(d.recommendedId);

    if (d.matched) {
      const nDoc = hospitals.reduce((a, h) => a + (h.onDutyCount || 0), 0);
      $('pinStatus').className = 'pin-status ok';
      $('pinStatus').innerHTML =
        `📍 <b>${d.area}</b> — ${hospitals.length} centres serve PIN ${pin}` +
        ` · <b>${nDoc} doctors on duty</b> · sorted nearest-first`;
    } else {
      $('pinStatus').className = 'pin-status warn';
      $('pinStatus').innerHTML = `⚠ ${d.message || 'PIN outside demo area'} — showing Patna district demo data.`;
    }
    if (hospitals.length) selectHospital(d.recommendedId || hospitals[0].id);
  } catch (e) {
    $('pinStatus').className = 'pin-status err';
    $('pinStatus').textContent = 'Server not reachable — is the backend running?';
    $('hospList').innerHTML = '<div class="hosp-card"><span style="color:#C0392B;font-size:14px;">API offline — start with: python3 start.py</span></div>';
  }
}

// ---------- hospital list ----------
function renderHospitals(recId) {
  $('hospList').innerHTML = hospitals.map(h => {
    const dist = h.distKm != null
      ? `<span class="chip-dist">📍 ${h.distKm} km · ~${h.travelMin} min auto</span>` : '';
    const docs = h.doctors || [];
    const docRows = docs.map(doc => `
      <div class="doc-row">
        <div class="doc-main">
          <span class="dot ${doc.onDuty ? 'on' : 'off'}"></span>
          <b>${doc.name}</b>
          <span class="doc-dept">${doc.dept}</span>
        </div>
        <div class="doc-sub">${doc.qual} · ${doc.exp} yrs · ${doc.langs}</div>
        <div class="doc-sub">🗓 ${doc.days} · 🕗 ${doc.hours} · 🚪 ${doc.room}
          <span class="doc-duty ${doc.onDuty ? 'on' : 'off'}">${doc.onDuty ? '● on duty today' : '○ off today'}</span></div>
      </div>`).join('');
    const docsBlock = docs.length ? `
      <details class="docs" data-stop="1">
        <summary>👨‍⚕️ ${docs.length} doctors · ${h.onDutyCount} on duty today</summary>
        ${docRows}
      </details>` : '';

    return `
    <div class="hosp-card" data-id="${h.id}" role="button" tabindex="0" aria-pressed="false">
      <div>
        <div class="hosp-name">${h.nameEn}</div>
        <div class="hosp-meta">🏥 ${h.address} · 🕗 ${h.timing} · ${h.dept}</div>
        <div class="hosp-badges">
          <span class="badge type">${h.type}</span>
          ${h.pmjay ? '<span class="badge pmjay">✓ PM-JAY</span>' : ''}
          ${h.id === recId ? '<span class="badge hamdard">🤖 Hamdard pick</span>' : ''}
          ${dist}
        </div>
        ${docsBlock}
      </div>
      <div class="hosp-q">
        <div class="qnum">${h.queue}</div>
        <div class="qlbl">in queue<br>~${TA.eta(h.etaMin)}</div>
      </div>
    </div>`;
  }).join('');

  document.querySelectorAll('.hosp-card').forEach(el => {
    const pick = () => selectHospital(Number(el.dataset.id));
    el.addEventListener('click', pick);
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
  });
  // expanding doctors must not select the hospital
  document.querySelectorAll('.docs').forEach(el => {
    el.addEventListener('click', e => e.stopPropagation());
    el.addEventListener('keydown', e => e.stopPropagation());
  });
}

function renderHamdard(recId) {
  const h = hospitals.find(x => x.id === recId);
  if (!h) return;
  const distTxt = h.distKm != null ? `<b>${h.distKm} km</b> from PIN ${currentPin}` : 'shortest line';
  $('hamdardLine').innerHTML =
    `For this visit, choose <b>${h.nameEn}</b> — ${distTxt} with a live line of
     ~${h.queue} people and <b>${h.onDutyCount} doctors on duty</b>.
     Treatment is <b style="color:var(--teal-deep)">free under PM-JAY</b>.`;
}

function selectHospital(id) {
  selectedId = id;
  // hint the ward TV which board to open (same origin → shared localStorage)
  try { localStorage.setItem('ta_hosp', String(id)); } catch (e) { /* private mode */ }
  document.querySelectorAll('.hosp-card').forEach(el => {
    const sel = Number(el.dataset.id) === id;
    el.classList.toggle('selected', sel);
    el.setAttribute('aria-pressed', sel ? 'true' : 'false');
  });
  const h = hospitals.find(x => x.id === id);
  if (h) {
    $('callStatus').textContent = `${h.nameEn} selected — ready when you are`;
    $('callBtn').disabled = false;
    refreshQueue();
  }
  if (myToken) {
    myToken = null;
    $('tokenBox').hidden = true;
    $('ivrBox').innerHTML = '';
    stopPolling();
  }
}

// ---------- missed call simulation ----------
async function giveMissedCall() {
  if (calling || !selectedId) return;
  calling = true;
  const btn = $('callBtn');
  const name = $('pName').value.trim() || 'Ramu';
  const phone = $('pPhone').value.replace(/\D/g, '');

  btn.disabled = true;
  btn.classList.add('ringing');
  btn.innerHTML = '📞 Ringing… cut after 2 rings';
  $('callStatus').textContent = 'Ringing…';
  $('ivrBox').innerHTML = '';
  $('tokenBox').hidden = true;

  const h = hospitals.find(x => x.id === selectedId);

  // 2 rings ≈ 2.2s
  await new Promise(r => setTimeout(r, 2200));

  btn.classList.remove('ringing');
  btn.innerHTML = '⏳ AI is calling you back…';
  $('callStatus').textContent = 'Cut! Waiting for the AI call-back…';

  try {
    const d = await TA.post('/api/token', { hospitalId: selectedId, name, phone });
    myToken = d.token;

    // IVR transcript with typed effect
    const ivrText = `नमस्ते ${name}! अपनी बारी में आपका स्वागत है।
आपकी बारी नंबर ${d.token.number} है — ${h ? h.nameEn : ''} OPD।
आपके आगे लगभग ${d.ahead} लोग हैं। घर आराम से रहें — बारी आने पर हम आपको कॉल करेंगे।`;
    $('ivrBox').innerHTML = `
      <div class="ivr-card fade-in">
        <div class="ivr-head">🔊 AI call-back · Hindi IVR</div>
        <div class="hi" id="ivrText"></div>
      </div>`;
    typeText($('ivrText'), ivrText);
    TA.speak(`नमस्ते ${name}! आपकी बारी नंबर ${d.token.number} है। आपके आगे लगभग ${d.ahead} लोग हैं। घर पर आराम से रहें।`);

    // token card
    $('tokHosp').textContent = h ? h.nameEn : '';
    $('tokNum').textContent = d.token.number;
    $('tokCode').textContent = d.token.code;
    $('tokAhead').textContent = d.ahead;
    $('tokEta').textContent = TA.eta(d.etaMin);
    $('tokCounter').textContent = '—';
    setBanner('wait', '🏠 Stay home — we\'ll call you when it\'s time.');
    $('tokenBox').hidden = false;

    btn.innerHTML = '📞 Give Missed Call';
    btn.disabled = false;
    calling = false;
    $('callStatus').textContent = 'Token received! Status updates every 3 seconds.';
    startPolling();
    refreshQueue();
  } catch (e) {
    btn.innerHTML = '📞 Give Missed Call';
    btn.disabled = false;
    calling = false;
    $('callStatus').textContent = 'Something went wrong — try again.';
  }
}

function typeText(el, text) {
  if (!el) return;
  let i = 0;
  const step = Math.max(1, Math.round(text.length / 90));
  const t = setInterval(() => {
    i += step;
    el.textContent = text.slice(0, i);
    if (i >= text.length) clearInterval(t);
  }, 24);
}

function setBanner(kind, msg) {
  const b = $('tokBanner');
  b.className = 'token-banner ' + kind;
  b.textContent = msg;
}

// ---------- live status polling ----------
function startPolling() {
  stopPolling();
  pollStatus();
  pollTimer = setInterval(pollStatus, 3000);
}
function stopPolling() {
  if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
}

async function pollStatus() {
  if (!myToken || !selectedId) return;
  try {
    const d = await TA.get(`/api/state?h=${selectedId}&number=${myToken.number}`);
    if (!d.ok || !d.me) return;
    const me = d.me;
    $('tokAhead').textContent = me.ahead;
    $('tokEta').textContent = TA.eta(me.etaMin);

    if (me.status === 'called') {
      $('tokCounter').textContent = me.counter || '–';
      setBanner('go', `🔔 बारी आ गई! Please go to Counter ${me.counter || 3}.`);
      if (!pollStatus.announced) {
        pollStatus.announced = true;
        TA.speak(`आपकी बारी आ गई है! कृपया काउंटर ${me.counter || 3} पर जाएँ।`);
      }
    } else if (me.status === 'done') {
      setBanner('done', '✅ Consultation done — get well soon!');
      stopPolling();
    } else if (me.status === 'noshow') {
      setBanner('wait', '⚠️ Your turn passed — please talk to the counter.');
    } else {
      pollStatus.announced = false;
      setBanner('wait', `🏠 Stay home — ${me.ahead} ahead of you.`);
    }
  } catch (e) { /* keep polling */ }
}

// ---------- live queue snapshot ----------
async function refreshQueue() {
  if (!selectedId) return;
  try {
    const d = await TA.get(`/api/state?h=${selectedId}`);
    if (!d.ok) return;
    const h = hospitals.find(x => x.id === selectedId);
    $('qHospName').textContent = h ? h.nameEn : '';
    $('qNow').textContent = d.nowServing || '—';
    $('qPending').textContent = d.pending;
    $('qAvg').textContent = d.avgWaitMin + ' min';
    $('qUpdated').textContent = 'live · updates 3s';
    $('qUpnext').innerHTML = d.upNext.length
      ? d.upNext.map(c => `<span class="tok">${c}</span>`).join('')
      : '<span style="color:var(--muted);font-size:13.5px;">Queue empty — seed it from the TV view</span>';
  } catch (e) { /* ignore */ }
}

// ---------- PM-JAY check ----------
async function checkPmjay() {
  const digits = $('pjDigits').value.replace(/\D/g, '');
  const box = $('pjResult');
  if (digits.length < 4) {
    box.className = 'pmjay-result no';
    box.innerHTML = 'Please enter at least 4 digits.';
    return;
  }
  try {
    const d = await TA.post('/api/pmjay', { digits });
    if (d.eligible) {
      box.className = 'pmjay-result ok';
      box.innerHTML = `<b class="big">🎉 Good news! Your family is likely covered under PM-JAY.</b><br>
        ₹5,00,000 free treatment per year — includes:
        <ul>${d.coverage.includes.map(x => `<li>${x}</li>`).join('')}</ul>
        <span style="display:block;margin-top:8px;font-size:12.5px;color:var(--muted);">
        (Demo check — real build verifies via ABDM / NPCI sandbox.)</span>`;
      TA.speak('खुशखबरी! आपका परिवार आयुष्मान भारत में शामिल है। पाँच लाख रुपये तक का इलाज मुफ़्त है।');
    } else {
      box.className = 'pmjay-result no';
      box.innerHTML = `<b class="big">Not found in this demo check.</b><br>
        But don't worry — <b>government hospital OPD is always free / ₹5</b>, and medicines at
        primary centres are free too. Take a token and go.`;
    }
  } catch (e) {
    box.className = 'pmjay-result no';
    box.innerHTML = 'Server not reachable.';
  }
}

// ---------- wire up ----------
document.addEventListener('DOMContentLoaded', () => {
  loadPincodes();

  // ?pin= from the landing quick-find box
  const urlPin = new URLSearchParams(location.search).get('pin');
  findNearby(urlPin || '800020', { silent: !urlPin });

  $('pinBtn').addEventListener('click', () => findNearby($('pinInput').value));
  $('pinInput').addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { e.preventDefault(); findNearby($('pinInput').value); }
  });
  $('pinInput').addEventListener('input', (e) => {
    e.target.value = e.target.value.replace(/\D/g, '').slice(0, 6);
  });

  $('callBtn').addEventListener('click', giveMissedCall);
  $('pjBtn').addEventListener('click', checkPmjay);
  $('pjDigits').addEventListener('keydown', (e) => { if (e.key === 'Enter') checkPmjay(); });
  setInterval(refreshQueue, 3000);
});
