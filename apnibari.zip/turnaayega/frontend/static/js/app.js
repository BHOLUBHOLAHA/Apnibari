/* ============================================================
   ApniBari — shared JS: API client + Hindi voice (TTS)
   ============================================================ */

const TA = {
  // ---------- API ----------
  async api(path, opts = {}) {
    const res = await fetch(path, {
      headers: { 'Content-Type': 'application/json' },
      ...opts,
    });
    if (!res.ok) throw new Error('API ' + path + ' → ' + res.status);
    return res.json();
  },
  get(path) { return TA.api(path); },
  post(path, body) {
    return TA.api(path, { method: 'POST', body: JSON.stringify(body || {}) });
  },

  // ---------- Hindi text-to-speech ----------
  ttsOn: localStorage.getItem('ta_tts') !== 'off',
  _voices: [],

  warmup() {
    if (!('speechSynthesis' in window)) return;
    const load = () => { TA._voices = speechSynthesis.getVoices(); };
    load();
    speechSynthesis.onvoiceschanged = load;
  },

  pickVoice() {
    return TA._voices.find(v => /^hi([-_]|$)/i.test(v.lang)) ||
           TA._voices.find(v => /hindi/i.test(v.name)) || null;
  },

  speak(text, { lang = 'hi-IN', rate = 0.92, force = false } = {}) {
    if (!('speechSynthesis' in window)) return;
    if (!TA.ttsOn && !force) return;
    try {
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang;
      u.rate = rate;
      const v = TA.pickVoice();
      if (v) u.voice = v;
      speechSynthesis.speak(u);
    } catch (e) { /* silent */ }
  },

  toggleTts() {
    TA.ttsOn = !TA.ttsOn;
    localStorage.setItem('ta_tts', TA.ttsOn ? 'on' : 'off');
    if (!TA.ttsOn) speechSynthesis.cancel();
    return TA.ttsOn;
  },

  // ---------- utils ----------
  pad(n) { return 'T-' + String(n).padStart(3, '0'); },

  eta(mins) {
    if (mins <= 0) return 'now';
    if (mins < 60) return '~' + mins + ' min';
    const h = Math.floor(mins / 60), m = mins % 60;
    return '~' + h + 'h' + (m ? ' ' + m + 'm' : '');
  },

  toast(msg, ms = 2600) {
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), ms);
  },
};

TA.warmup();

// ---------- landing quick-find: PIN → demo with that pin ----------
document.addEventListener('DOMContentLoaded', () => {
  const heroPin = document.getElementById('heroPin');
  const heroGo = document.getElementById('heroPinGo');
  if (!heroPin || !heroGo) return;
  const go = () => {
    const pin = (heroPin.value || '').replace(/\D/g, '').slice(0, 6);
    location.href = '/demo' + (pin.length === 6 ? '?pin=' + pin : '');
  };
  heroGo.addEventListener('click', (e) => { e.preventDefault(); go(); });
  heroPin.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(); } });
  heroPin.addEventListener('input', () => {
    heroPin.value = heroPin.value.replace(/\D/g, '').slice(0, 6);
  });
});
