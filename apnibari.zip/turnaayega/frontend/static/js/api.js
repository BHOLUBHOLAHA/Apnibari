/* ============================================================
   ApniBari — Backend API Console (js/api.js)
   Renders a try-it-out explorer for every Tier-2 endpoint.
   All calls go to the same origin (/api/...): on the public
   preview the frontend proxy forwards them to :8001, inside
   the sandbox you could point BASE at http://localhost:8001.
   ============================================================ */

"use strict";

const $ = (s, el) => (el || document).querySelector(s);

/* ---------------- endpoint catalog ---------------- */
/* p: query param · b: body field · sel: dynamic hospital select */
const GROUPS = [
  {
    name: "System", items: [
      { m: "GET", path: "/api/health", desc: "Liveness probe + SQLite status. Use this as the uptime check.", params: [] },
      { m: "GET", path: "/api/docs", desc: "Self-documenting catalog — the backend describes its own API.", params: [] },
    ],
  },
  {
    name: "Discovery & Location", items: [
      { m: "GET", path: "/api/pincodes", desc: "All 15 India Post PIN zones of the demo service area (Patna district).", params: [] },
      { m: "GET", path: "/api/nearby", desc: "Hospitals sorted by Haversine distance from a PIN + Hamdard smart pick (dist + 0.1·queue). Unknown PINs degrade honestly to queue-ranking.",
        params: [{ k: "pin", type: "text", def: "800020" }] },
      { m: "GET", path: "/api/hospitals", desc: "Every facility with live queue depth, doctors on duty and the Hamdard recommendation.", params: [] },
      { m: "GET", path: "/api/doctors", desc: "Doctor roster of one hospital — qualification, OPD hours, room, languages, duty flag.",
        params: [{ k: "h", type: "hospital", def: "3" }] },
    ],
  },
  {
    name: "Live Queue", items: [
      { m: "GET", path: "/api/state", desc: "Now-serving, up-next, average wait — and a per-token tracker when ?number= is given.",
        params: [{ k: "h", type: "hospital", def: "3" }, { k: "number", type: "number", def: "", ph: "e.g. 7 (optional)" }] },
      { m: "POST", path: "/api/token", desc: "Simulates the missed call: registers a patient and returns their token + ETA (4 min/person).",
        params: [{ k: "hospitalId", type: "hospital", def: "3" },
                 { k: "name", type: "text", def: "Ramesh Kumar" },
                 { k: "phone", type: "text", def: "9800000000" },
                 { k: "pmjay", type: "check", def: true }] },
      { m: "POST", path: "/api/call-next", desc: "Ward staff action: announce the next patient (drives the Hindi IVR + TV board).",
        params: [{ k: "hospitalId", type: "hospital", def: "3" }] },
      { m: "POST", path: "/api/noshow", desc: "Mark the patient who was just called as absent — queue moves on.",
        params: [{ k: "hospitalId", type: "hospital", def: "3" }] },
    ],
  },
  {
    name: "Staff & Admin", items: [
      { m: "POST", path: "/api/staff/login", desc: "Ward-staff PIN → demo session token (real build: signed JWT). Try 2026 — and a wrong one.",
        params: [{ k: "pin", type: "text", def: "2026" }] },
      { m: "POST", path: "/api/doctors/duty", desc: "Toggle a doctor on/off duty (DB row id 1–15). Roster and counts update everywhere.",
        params: [{ k: "doctorId", type: "number", def: "1" },
                 { k: "onDuty", type: "check", def: false }] },
      { m: "GET", path: "/api/stats", desc: "Today-at-a-glance: tokens issued, served, no-shows, avg wait — the admin analytics feed.", params: [] },
      { m: "GET", path: "/api/call-log", desc: "Append-only audit trail of every token / announce / no-show event.",
        params: [{ k: "h", type: "hospital", def: "" }, { k: "limit", type: "number", def: "10" }] },
      { m: "POST", path: "/api/seed", desc: "Demo-fill the queue (hospitalId omitted ⇒ all hospitals).",
        params: [{ k: "hospitalId", type: "hospital", def: "3" }, { k: "count", type: "number", def: "6" }] },
      { m: "POST", path: "/api/reset", desc: "Clear today's queue (hospitalId omitted ⇒ everywhere).",
        params: [{ k: "hospitalId", type: "hospital", def: "" }] },
    ],
  },
  {
    name: "Schemes", items: [
      { m: "POST", path: "/api/pmjay", desc: "PM-JAY eligibility (demo rule: digit-sum even ⇒ covered, ₹5 lakh/family).",
        params: [{ k: "digits", type: "text", def: "4321 8765" }] },
    ],
  },
];

/* ---------------- JSON highlighting ---------------- */
function esc(s) { return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
function hi(json) {
  return esc(JSON.stringify(json, null, 2)).replace(
    /("(\\u[a-fA-F0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(\.\d+)?([eE][+-]?\d+)?)/g,
    (m) => {
      let cls = "jn";
      if (/^"/.test(m)) cls = /:$/.test(m) ? "jk" : "js";
      else if (/true|false|null/.test(m)) cls = "jb";
      return `<span class="${cls}">${m}</span>`;
    });
}

/* ---------------- response pane ---------------- */
function renderResp(pane, status, ms, data) {
  const cls = status < 300 ? "s2" : status < 500 ? "s4" : "s5";
  pane.innerHTML =
    `<div class="resp-bar">HTTP <span class="status ${cls}">${status}</span>` +
    `<span>${(data && data.ok === false) ? "⚠ " + esc(String(data.error || data.message || "")) : "ok"}</span>` +
    `<span class="lat">${ms} ms</span></div>` +
    `<pre>${hi(data)}</pre>`;
  pane.classList.add("open");
}

async function run(url, opts, pane, btn) {
  btn.disabled = true; btn.textContent = "…";
  const t0 = performance.now();
  try {
    const r = await fetch(url, opts);
    let data = null;
    try { data = await r.json(); } catch { data = { raw: "(non-JSON response)" }; }
    renderResp(pane, r.status, Math.round(performance.now() - t0), data);
  } catch (e) {
    renderResp(pane, 0, Math.round(performance.now() - t0), { ok: false, error: String(e) });
  }
  btn.disabled = false; btn.textContent = "▶ Run";
}

/* ---------------- hospital selects ---------------- */
let HOSPITALS = [];
async function loadHospitals() {
  try {
    const r = await fetch("/api/hospitals");
    const d = await r.json();
    HOSPITALS = d.hospitals || [];
  } catch { HOSPITALS = []; }
  document.querySelectorAll("select[data-hosp]").forEach((sel) => {
    const cur = sel.dataset.keep || sel.value;
    sel.innerHTML = HOSPITALS.map(
      (h) => `<option value="${h.id}">${h.id} · ${h.nameEn}</option>`).join("") ||
      `<option value="3">3 · District Hospital</option>`;
    if (cur) sel.value = cur;
  });
}

/* ---------------- card builder ---------------- */
function paramInput(p) {
  if (p.type === "hospital") {
    const all = p.def === "" ? `<option value="">All hospitals</option>` : "";
    return `<div class="param"><label>${p.k}</label>
      <select data-hosp data-pk="${p.k}">${all}<option value="${p.def || ""}">loading…</option></select></div>`;
  }
  if (p.type === "check") {
    return `<div class="param check"><input type="checkbox" id="ck_${p.k}"
      data-pk="${p.k}" ${p.def ? "checked" : ""}><label for="ck_${p.k}">${p.k}</label></div>`;
  }
  return `<div class="param"><label>${p.k}</label>
    <input type="${p.type === "number" ? "number" : "text"}" data-pk="${p.k}"
      value="${esc(String(p.def || ""))}" placeholder="${esc(p.ph || "")}"></div>`;
}

function buildCard(it) {
  const card = document.createElement("div");
  card.className = "ep";
  card.innerHTML =
    `<div class="ep-head"><span class="method ${it.m}">${it.m}</span>` +
    `<span class="ep-path">${it.path}</span>` +
    `<button class="btn-run" style="margin-left:auto">▶ Run</button>` +
    `<div class="ep-desc">${it.desc}</div></div>` +
    `<div class="ep-body"><div class="params">${it.params.map(paramInput).join("")}</div>` +
    `<div class="resp"></div></div>`;

  const btn = $(".btn-run", card), pane = $(".resp", card);
  btn.addEventListener("click", () => {
    const q = new URLSearchParams(), body = {};
    card.querySelectorAll("[data-pk]").forEach((el) => {
      const k = el.dataset.pk;
      const v = el.type === "checkbox" ? el.checked : el.value.trim();
      if (v === "" || v === false) return;
      const numeric = el.type === "number" || (el.tagName === "SELECT" && /^\d+$/.test(v)) || k === "hospitalId";
      const val = numeric && !isNaN(Number(v)) ? Number(v) : v;
      if (it.m === "GET") q.set(k, v); else body[k] = val;
    });
    const qs = q.toString() ? `?${q}` : "";
    const opts = it.m === "POST"
      ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }
      : {};
    run(it.path + qs, opts, pane, btn);
  });
  return card;
}

/* ---------------- mount explorer ---------------- */
function mount() {
  const root = $("#explorer");
  let n = 0;
  GROUPS.forEach((g, gi) => {
    const t = document.createElement("div");
    t.className = "grp-title";
    t.innerHTML = `<span>${g.name}</span><span class="n">${g.items.length}</span>`;
    root.appendChild(t);
    g.items.forEach((it) => { root.appendChild(buildCard(it)); n++; });
  });
  return n;
}

/* ---------------- happy-path runner ---------------- */
async function happyPath() {
  const log = $("#flowLog"), btn = $("#flowBtn");
  btn.disabled = true; btn.textContent = "running…";
  log.classList.add("open");
  log.innerHTML = "";
  const post = (p, b) => ({ m: "POST", p, b });
  const get = (p) => ({ m: "GET", p, b: null });
  const steps = [
    { ...post("/api/seed", { hospitalId: 3, count: 6 }), why: "fill the OPD queue" },
    { ...post("/api/token", { hospitalId: 3, name: "API Tester", phone: "9800000000", pmjay: true }), why: "missed call → new token" },
    { ...get("/api/state?h=3"), why: "queue state" },
    { ...post("/api/call-next", { hospitalId: 3 }), why: "announce next patient" },
    { ...get("/api/state?h=3"), why: "state after announce" },
  ];
  for (let i = 0; i < steps.length; i++) {
    const s = steps[i];
    const det = document.createElement("details");
    det.innerHTML = `<summary>step ${i + 1}/5 · ${s.m} ${esc(s.p)} — <i>${s.why}</i> …</summary>`;
    log.appendChild(det);
    const t0 = performance.now();
    try {
      const r = await fetch(s.p, s.b === null ? {} :
        { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(s.b) });
      const d = await r.json();
      const ms = Math.round(performance.now() - t0);
      let hint = "";
      if (d.token && typeof d.token === "object") hint = `→ ${d.token.code} (#${d.token.number})`;
      else if (typeof d.token === "string") hint = `→ ${d.token}`;
      else if (d.code) hint = `→ now serving ${d.code}`;
      else if (typeof d.pending === "number") hint = `→ ${d.pending} waiting, serving ${d.nowServing || "—"}`;
      else if (typeof d.added === "number") hint = `→ +${d.added} tokens`;
      det.querySelector("summary").innerHTML =
        `step ${i + 1}/5 · ${s.m} ${esc(s.p)} — <i>${s.why}</i> ` +
        `<span class="status ${r.status < 300 ? "s2" : "s4"}">${r.status}</span> ${ms} ms ${esc(hint)}`;
      const pre = document.createElement("pre");
      pre.innerHTML = hi(d);
      det.appendChild(pre);
    } catch (e) {
      det.querySelector("summary").textContent = `step ${i + 1} failed: ${e}`;
    }
  }
  btn.disabled = false; btn.textContent = "Run flow";
}

/* ---------------- boot ---------------- */
(async function boot() {
  const n = mount();
  await loadHospitals();
  // health chip
  try {
    const r = await fetch("/api/health");
    const d = await r.json();
    const chip = $("#healthChip");
    chip.classList.add("live");
    chip.innerHTML = `<span class="dot"></span> backend live · ${d.tokens} token(s) in db`;
  } catch {
    $("#healthChip").innerHTML = `<span class="dot"></span> backend offline`;
  }
  // public URL card
  $("#pubUrl").textContent = location.origin + "/api/health";
  $("#flowBtn").addEventListener("click", happyPath);
  console.info(`ApniBari console ready — ${n} endpoints`);
})();
