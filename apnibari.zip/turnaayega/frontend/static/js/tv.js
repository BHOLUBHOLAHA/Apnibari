/* ============================================================
   ApniBari — Hospital TV display
   Now-serving board + Hindi voice announcements (Web Speech API)
   ============================================================ */

let hospitals = [];
// open the board for the hospital the patient demo last selected
// (falls back to the busiest queue once the list loads)
let hospitalId = (() => {
  try { return Number(localStorage.getItem('ta_hosp')) || 0; } catch (e) { return 0; }
})();
let lastServing = null;
let lastServedCount = null;
let pollTimer = null;

const $ = (id) => document.getElementById(id);

// ---------- clock ----------
function tickClock() {
  const now = new Date();
  $('tvClock').textContent = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  $('tvDate').textContent = now.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
}

// ---------- hospitals ----------
async function loadHospitals() {
  try {
    const d = await TA.get('/api/hospitals');
    hospitals = d.hospitals || [];
    $('tvHosp').innerHTML = hospitals.map(h =>
      `<option value="${h.id}">${h.nameEn}</option>`).join('');
    if (!hospitals.some(h => h.id === hospitalId)) {
      // no valid hint → default to the hospital with the longest live queue
      const busiest = hospitals.reduce((a, b) => (b.queue > (a?.queue ?? -1) ? b : a), null);
      hospitalId = busiest ? busiest.id : 3;
    }
    $('tvHosp').value = String(hospitalId);
    startPolling();                 // restart poll for the resolved hospital
  } catch (e) { /* retry on next poll */ }
}

// ---------- main poll ----------
async function poll() {
  try {
    const d = await TA.get(`/api/state?h=${hospitalId}`);
    if (!d.ok) return;

    $('tvHospName').innerHTML = `${d.hospital.nameEn} <span class="baari">· OPD</span>`;
    $('tvPending').textContent = d.pending;
    $('tvAvg').textContent = d.avgWaitMin + 'm';

    // now serving + announce on change
    const serving = d.nowServingNum;
    const numEl = $('tvNum');
    if (serving !== null && serving !== lastServing) {
      numEl.textContent = d.nowServing;
      numEl.classList.remove('idle');
      numEl.classList.remove('flash');
      void el_offsetWidth(numEl);        // restart animation
      numEl.classList.add('flash');
      $('tvSay').innerHTML =
        `<span class="hi">कृपया नंबर ${d.nowServing}, काउंटर ${d.nowServingCounter} पर आएँ</span>
         &nbsp;<span class="counter-pill">Counter ${d.nowServingCounter}</span>`;
      TA.speak(`नंबर ${d.nowServing}, बारी आ गई। कृपया काउंटर ${d.nowServingCounter} पर आएँ।`);
      lastServing = serving;
    } else if (serving === null && lastServing !== null) {
      numEl.textContent = '—';
      numEl.classList.add('idle');
      $('tvSay').textContent = 'Waiting for the next token…';
      lastServing = null;
    }

    // up-next list
    $('tvNext').innerHTML = d.upNext.length
      ? d.upNext.map((c, i) =>
          `<div class="tv-tok"><span class="c">${c}</span><span class="s">${i === 0 ? 'next' : i + 1 + ' in line'}</span></div>`).join('')
      : '<div class="tv-tok"><span class="c">—</span><span class="s">queue empty</span></div>';

    // served today = tokens with status done
    if (typeof d.servedToday === 'number' && d.servedToday !== lastServedCount) {
      $('tvServed').textContent = d.servedToday;
      lastServedCount = d.servedToday;
    }

    // next free ETA
    $('tvEta').textContent = d.pending > 0 ? TA.eta(d.avgWaitMin) : 'now';
  } catch (e) { /* keep polling */ }
}

function el_offsetWidth(el) { return el.offsetWidth; }

function startPolling() {
  if (pollTimer) clearInterval(pollTimer);
  poll();
  pollTimer = setInterval(poll, 2000);
}

// ---------- staff actions ----------
async function callNext() {
  try {
    const d = await TA.post('/api/call-next', { hospitalId });
    if (d.ok) {
      TA.speak(`नंबर ${d.number}, बारी आ गई। कृपया काउंटर ${d.counter} पर आएँ।`);
      TA.toast(`Now serving ${d.code} — ${d.name} @ Counter ${d.counter}`);
    } else {
      TA.toast(d.message || 'No patient waiting');
    }
  } catch (e) { TA.toast('Server not reachable'); }
}

async function noshow() {
  await TA.post('/api/noshow', { hospitalId });
  TA.toast('Marked no-show — next patient, please');
}

async function seed() {
  const d = await TA.post('/api/seed', { hospitalId, count: 40 });
  TA.toast(`Added ${d.added} demo patients to the queue`);
}

async function reset() {
  const d = await TA.post('/api/reset', { hospitalId });
  lastServing = null;
  $('tvNum').textContent = '—';
  $('tvSay').textContent = 'Waiting for the next token…';
  TA.toast(`Queue cleared (${d.removed} tokens)`);
}

// ---------- controls visibility (fullscreen-friendly) ----------
function toggleControls() {
  const c = $('tvControls');
  c.style.display = (c.style.display === 'none') ? 'flex' : 'none';
}

// ---------- wire up ----------
document.addEventListener('DOMContentLoaded', () => {
  tickClock();
  setInterval(tickClock, 1000);
  loadHospitals();
  startPolling();

  $('tvHosp').addEventListener('change', (e) => {
    hospitalId = Number(e.target.value);
    lastServing = null;
    startPolling();
  });
  $('btnNext').addEventListener('click', callNext);
  $('btnNoshow').addEventListener('click', noshow);
  $('btnSeed').addEventListener('click', seed);
  $('btnReset').addEventListener('click', reset);
  $('btnHide').addEventListener('click', toggleControls);
  $('btnTts').addEventListener('click', (e) => {
    const on = TA.toggleTts();
    e.target.textContent = on ? '🔊 Voice: On' : '🔇 Voice: Off';
    e.target.classList.toggle('off', !on);
  });
  document.addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'h') toggleControls();
    if (e.key.toLowerCase() === 'n') callNext();
  });

  // reflect stored TTS preference
  if (!TA.ttsOn) {
    $('btnTts').textContent = '🔇 Voice: Off';
    $('btnTts').classList.add('off');
  }
});
