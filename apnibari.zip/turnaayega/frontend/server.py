#!/usr/bin/env python3
# ============================================================
#  ApniBari FRONTEND — static site server + API proxy
#  Serves the UI on :3000 (default). Contains NO business
#  logic: every /api/* request is proxied over HTTP to the
#  backend tier (backend/app.py on :8001) — exactly how nginx
#  sits in front of an API service in production.
#
#  Standalone run:   python3 frontend/server.py
#  (backend must be up: python3 backend/app.py)
# ============================================================

import http.client
import json
import os
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

BASE = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(BASE, "static")
PORT = int(os.environ.get("PORT", "3000"))
BACKEND_HOST = os.environ.get("BACKEND_HOST", "127.0.0.1")
BACKEND_PORT = int(os.environ.get("BACKEND_PORT", "8001"))

MIME = {
    ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8", ".json": "application/json",
    ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg", ".webp": "image/webp", ".ico": "image/x-icon",
    ".woff2": "font/woff2",
}

PAGES = {"/": "index.html", "/index.html": "index.html",
         "/demo": "demo.html", "/demo.html": "demo.html",
         "/tv": "tv.html", "/tv.html": "tv.html",
         "/console": "api.html", "/console.html": "api.html", "/api.html": "api.html"}


class FrontendHandler(BaseHTTPRequestHandler):
    server_version = "ApniBariWeb/1.0"

    # ---------- static ----------
    def _file(self, rel):
        path = os.path.normpath(os.path.join(STATIC, rel))
        if not path.startswith(STATIC) or not os.path.isfile(path):
            return self._json(404, {"ok": False, "error": "not found"})
        ext = os.path.splitext(path)[1].lower()
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", MIME.get(ext, "application/octet-stream"))
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):
        pass

    # ---------- API proxy (frontend tier → backend tier) ----------
    def _proxy(self):
        u = urlparse(self.path)
        n = int(self.headers.get("Content-Length") or 0)
        payload = self.rfile.read(n) if n else None
        try:
            conn = http.client.HTTPConnection(BACKEND_HOST, BACKEND_PORT, timeout=8)
            conn.request(self.command, u.path + ("?" + u.query if u.query else ""),
                         body=payload,
                         headers={"Content-Type": self.headers.get("Content-Type",
                                                                   "application/json")})
            resp = conn.getresponse()
            data = resp.read()
            conn.close()
        except (OSError, http.client.HTTPException):
            return self._json(502, {"ok": False,
                                    "error": "backend offline — start backend/app.py"})
        self.send_response(resp.status)
        ctype = resp.getheader("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    # ---------- routing ----------
    def do_GET(self):
        p = urlparse(self.path).path
        if p.startswith("/api/"):
            return self._proxy()
        rel = PAGES.get(p)
        if rel:
            return self._file(rel)
        if p.startswith("/css/") or p.startswith("/js/") or p.startswith("/img/"):
            return self._file(p.lstrip("/"))
        return self._file("index.html")

    def do_POST(self):
        if urlparse(self.path).path.startswith("/api/"):
            return self._proxy()
        return self._json(404, {"ok": False, "error": "not found"})


class FrontendServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def serve(port=None):
    port = port or PORT
    httpd = FrontendServer(("0.0.0.0", port), FrontendHandler)
    print(f"  [frontend] ApniBari UI + /api proxy → http://0.0.0.0:{port}  (tier 1)", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    print(f"""
  🟢 ApniBari frontend — static UI (logic lives in the backend)
     UI  : http://localhost:{PORT}/
     API : proxied → http://{BACKEND_HOST}:{BACKEND_PORT}/api/…
""", flush=True)
    try:
        serve()
    except OSError:
        print(f"Port {PORT} already in use — frontend not started.", flush=True)
