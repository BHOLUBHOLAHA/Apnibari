# ============================================================
#  ApniBari backend — demo datasets
#  NOTE: seed data for the hackathon demo. Pincodes & coords are
#  India Post zones for PATNA district (approx centroids);
#  hospitals & doctors are demo records.
#  Real build would pull: India Post PIN API + ABDM facility registry.
# ============================================================

# 5 government facilities serving the demo district.
# lat/lng power precise distance from the patient's PIN code.
HOSPITALS = [
    {"id": 1, "nameEn": "Ayushman Arogya Mandir (Village)", "nameHi": "आयुष्मान आरोग्य मंदिर",
     "type": "HWC", "lat": 25.4890, "lng": 85.0810,
     "address": "Naubatpur Block, Rural Patna", "timing": "8 AM – 12 PM",
     "dept": "General, Childcare, Pharmacy", "pmjay": True, "baseQueue": 8},
    {"id": 2, "nameEn": "Primary Health Centre", "nameHi": "प्राथमिक स्वास्थ्य केंद्र",
     "type": "PHC", "lat": 25.5950, "lng": 85.0850,
     "address": "Phulwari Sharif, Patna", "timing": "9 AM – 1 PM",
     "dept": "General, Maternity, Pharmacy", "pmjay": True, "baseQueue": 14},
    {"id": 3, "nameEn": "District Hospital", "nameHi": "जिला अस्पताल",
     "type": "District", "lat": 25.6150, "lng": 85.1430,
     "address": "Gandhi Maidan, Central Patna", "timing": "8 AM – 2 PM",
     "dept": "All departments, X-ray, Lab", "pmjay": True, "baseQueue": 31},
    {"id": 4, "nameEn": "Community Health Centre", "nameHi": "सामुदायिक स्वास्थ्य केंद्र",
     "type": "CHC", "lat": 25.6300, "lng": 85.0480,
     "address": "Danapur Cantt, Patna", "timing": "9 AM – 2 PM",
     "dept": "General, Dental, Eye, Maternity", "pmjay": True, "baseQueue": 12},
    {"id": 5, "nameEn": "Medical College Hospital", "nameHi": "मेडिकल कॉलेज अस्पताल",
     "type": "Medical College", "lat": 25.5850, "lng": 85.1650,
     "address": "Kankarbagh, Patna", "timing": "8 AM – 2 PM",
     "dept": "Specialists, Surgery, ICU", "pmjay": True, "baseQueue": 44},
]

# Fallback reference point (Patna City centre) when no PIN is given.
CENTRE = {"pin": "800001", "area": "Patna City", "lat": 25.6093, "lng": 85.1376}

# India Post PIN zones of the demo service area (Patna district, Bihar).
PINCODES = [
    {"pin": "800001", "area": "Patna City",        "lat": 25.6093, "lng": 85.1376},
    {"pin": "800004", "area": "Gandhi Maidan",     "lat": 25.6170, "lng": 85.1450},
    {"pin": "800006", "area": "Kadam Kuan",        "lat": 25.6250, "lng": 85.1460},
    {"pin": "800013", "area": "Boring Road",       "lat": 25.6180, "lng": 85.1180},
    {"pin": "800016", "area": "Rajbansi Nagar",    "lat": 25.6080, "lng": 85.1210},
    {"pin": "800020", "area": "Kankarbagh",        "lat": 25.5940, "lng": 85.1580},
    {"pin": "800023", "area": "Rajendra Nagar",    "lat": 25.6060, "lng": 85.1560},
    {"pin": "800025", "area": "Alamganj",          "lat": 25.6130, "lng": 85.1660},
    {"pin": "801503", "area": "Danapur Cantt",     "lat": 25.6300, "lng": 85.0500},
    {"pin": "801505", "area": "Phulwari Sharif",   "lat": 25.5950, "lng": 85.0820},
    {"pin": "801108", "area": "Maner",             "lat": 25.6470, "lng": 84.8760},
    {"pin": "803201", "area": "Fatuha",            "lat": 25.4930, "lng": 85.3230},
    {"pin": "803202", "area": "Bakhtiarpur",       "lat": 25.5040, "lng": 85.5330},
    {"pin": "803213", "area": "Barh",              "lat": 25.4750, "lng": 85.7090},
    {"pin": "804452", "area": "Masaurhi",          "lat": 25.3540, "lng": 85.0330},
]

# Doctor roster per hospital id — demo records.
DOCTORS = {
    1: [
        {"name": "Dr. Meena Kumari", "dept": "General Medicine", "qual": "MBBS",
         "days": "Mon–Sat", "hours": "8 AM – 12 PM", "room": "Room 2",
         "onDuty": True, "exp": 6, "langs": "Hindi, Bhojpuri"},
        {"name": "Dr. Arvind Singh", "dept": "Childcare", "qual": "MBBS, DCH",
         "days": "Tue, Thu, Fri", "hours": "8 AM – 12 PM", "room": "Room 3",
         "onDuty": True, "exp": 4, "langs": "Hindi"},
    ],
    2: [
        {"name": "Dr. Sanjay Paswan", "dept": "General Medicine", "qual": "MBBS",
         "days": "Mon–Sat", "hours": "9 AM – 1 PM", "room": "Room 1",
         "onDuty": True, "exp": 11, "langs": "Hindi, English"},
        {"name": "Dr. Rekha Devi", "dept": "Maternity", "qual": "MBBS, DGO",
         "days": "Mon, Wed, Sat", "hours": "9 AM – 1 PM", "room": "Room 4",
         "onDuty": False, "exp": 8, "langs": "Hindi, Bhojpuri"},
    ],
    3: [
        {"name": "Dr. S. K. Verma", "dept": "General Medicine", "qual": "MD (Medicine)",
         "days": "Mon–Sat", "hours": "8 AM – 2 PM", "room": "Room 12",
         "onDuty": True, "exp": 17, "langs": "Hindi, English"},
        {"name": "Dr. Anita Prasad", "dept": "Gynaecology", "qual": "MS (OBG)",
         "days": "Mon–Sat", "hours": "9 AM – 1 PM", "room": "Room 7",
         "onDuty": True, "exp": 12, "langs": "Hindi, English"},
        {"name": "Dr. Md. Faisal", "dept": "Orthopaedics", "qual": "MS (Ortho)",
         "days": "Tue, Thu", "hours": "10 AM – 2 PM", "room": "Room 9",
         "onDuty": True, "exp": 9, "langs": "Hindi, Urdu"},
        {"name": "Dr. Kavita Jha", "dept": "Paediatrics", "qual": "MD (Paed)",
         "days": "Mon–Sat", "hours": "8 AM – 2 PM", "room": "Room 5",
         "onDuty": True, "exp": 10, "langs": "Hindi, Maithili"},
    ],
    4: [
        {"name": "Dr. Ramesh Chandra", "dept": "General Medicine", "qual": "MBBS",
         "days": "Mon–Sat", "hours": "9 AM – 2 PM", "room": "Room 2",
         "onDuty": True, "exp": 14, "langs": "Hindi, Bhojpuri"},
        {"name": "Dr. Shalini Roy", "dept": "Dental", "qual": "BDS",
         "days": "Mon, Wed, Fri", "hours": "10 AM – 1 PM", "room": "Room 6",
         "onDuty": False, "exp": 5, "langs": "Hindi, English"},
        {"name": "Dr. Iqbal Ahmed", "dept": "Eye", "qual": "MS (Ophthal)",
         "days": "Tue, Thu", "hours": "9 AM – 1 PM", "room": "Room 6-B",
         "onDuty": True, "exp": 13, "langs": "Hindi, Urdu"},
    ],
    5: [
        {"name": "Dr. P. K. Sinha", "dept": "Cardiology", "qual": "DM (Cardio)",
         "days": "Tue, Thu, Sat", "hours": "9 AM – 1 PM", "room": "Room 201",
         "onDuty": True, "exp": 22, "langs": "Hindi, English"},
        {"name": "Dr. Nisha Verma", "dept": "Neurology", "qual": "DM (Neuro)",
         "days": "Mon, Wed", "hours": "10 AM – 1 PM", "room": "Room 205",
         "onDuty": False, "exp": 15, "langs": "Hindi, English"},
        {"name": "Dr. Alok Ranjan", "dept": "General Surgery", "qual": "MS (Surgery)",
         "days": "Mon–Sat", "hours": "8 AM – 2 PM", "room": "Room 210",
         "onDuty": True, "exp": 18, "langs": "Hindi"},
        {"name": "Dr. Farah Khan", "dept": "Skin (Dermatology)", "qual": "MD (Derm)",
         "days": "Mon–Thu", "hours": "11 AM – 2 PM", "room": "Room 214",
         "onDuty": True, "exp": 7, "langs": "Hindi, English"},
    ],
}

SEED_NAMES = ["Ramu", "Sunita", "Arjun", "Kavita", "Mohan", "Pooja", "Ramesh", "Anita",
              "Vijay", "Lakshmi", "Suresh", "Geeta", "Dinesh", "Rekha", "Amit", "Shanti",
              "Pankaj", "Meena", "Rajesh", "Sarita", "Vikram", "Nisha", "Om Prakash", "Devi"]
