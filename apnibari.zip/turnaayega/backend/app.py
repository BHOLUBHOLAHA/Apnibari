#!/usr/bin/env python3
# ============================================================
#  ApniBari BACKEND — standalone JSON API + SQLite database
#  No HTML, no static files. Runs on :8001 by default.
#  State lives in apnibari.db (WAL); tokens, counters and a
#  full call audit trail are SQL tables.
#
#  Standalone run:   python3 backend/app.py
#  Endpoints:
#    GET  /api/health                     liveness + db status
#    GET  /api/docs                       self-documenting catalog
#    GET  /api/hospitals                  list + live queue (no PIN context)
#    GET  /api/pincodes                   searchable PIN zone dataset
#    GET  /api/nearby?pin=800020          hospitals sorted by distance + doctors
#    GET  /api/doctors?h=3                doctor roster for one hospital
#    GET  /api/state?h=&number=           queue state + "my token" tracker
#    GET  /api/stats                      today-at-a-glance (admin analytics)
#    GET  /api/call-log?h=&limit=         audit trail (token/announce/noshow)
#    POST /api/token                      register a missed-call token
#    POST /api/call-next                  staff: announce next patient
#    POST /api/noshow                     staff: mark called patient absent
#    POST /api/doctors/duty               admin: toggle doctor on/off duty
#    POST /api/staff/login                staff PIN → demo session token
#    POST /api/seed                       demo-fill queue
#    POST /api/reset                      clear queue
#    POST /api/pmjay                      PM-JAY eligibility (demo rule)
# ============================================================

import json
import os
import random
import secrets
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import data as D
import db as DB
import store as S

PORT = int(os.environ.get("BACKEND_PORT", "8001"))
STAFF_PIN = os.environ.get("STAFF_PIN", "2026")   # demo ward-staff PIN

DOCS = [
    {"method": "GET",  "path": "/api/health",       "desc": "liveness + sqlite status"},
    {"method": "GET",  "path": "/api/docs",         "desc": "this catalog"},
    {"method": "GET",  "path": "/api/hospitals",    "desc": "hospitals + live queue + doctors"},
    {"method": "GET",  "path": "/api/pincodes",     "desc": "searchable PIN zones"},
    {"method": "GET",  "path": "/api/nearby?pin=",  "desc": "hospitals sorted by distance + Hamdard pick"},
    {"method": "GET",  "path": "/api/doctors?h=",   "desc": "doctor roster for one hospital"},
    {"method": "GET",  "path": "/api/state?h=&number=", "desc": "now serving / up next / my token"},
    {"method": "GET",  "path": "/api/stats",        "desc": "today-at-a-glance analytics"},
    {"method": "GET",  "path": "/api/call-log?h=",  "desc": "audit trail (token/announce/noshow)"},
    {"method": "POST", "path": "/api/token",        "desc": "register missed-call token {hospitalId,name,phone}"},
    {"method": "POST", "path": "/api/call-next",    "desc": "announce next patient {hospitalId}"},
    {"method": "POST", "path": "/api/noshow",       "desc": "mark called patient absent {hospitalId}"},
    {"method": "POST", "path": "/api/doctors/duty", "desc": "toggle duty {doctorId,onDuty}"},
    {"method": "POST", "path": "/api/staff/login",  "desc": "staff PIN → session token {pin}"},
    {"method": "POST", "path": "/api/seed",         "desc": "demo-fill queue {hospitalId,count}"},
    {"method": "POST", "path": "/api/reset",        "desc": "clear queue {hospitalId?}"},
    {"method": "POST", "path": "/api/pmjay",        "desc": "eligibility check {digits}"},
]


def _day_start():
    lt = time.localtime()
    return time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1))


class ApiHandler(BaseHTTPRequestHandler):
    server_version = "ApniBariAPI/2.0"

    # ---------- helpers ----------
    def _headers(self, code, ctype="application/json; charset=utf-8", length=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        if length is not None:
            self.send_header("Content-Length", str(length))
        # open CORS so the API can be consumed from any origin (two-tier demo)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _json(self, code, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self._headers(code, length=len(body))
        self.wfile.write(body)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n).decode("utf-8") if n else "{}"
            return json.loads(raw or "{}")
        except Exception:
            return {}

    def log_message(self, *a):
        pass

    # ---------- routing ----------
    def do_OPTIONS(self):
        self._headers(204, length=0)

    def do_GET(self):
        u = urlparse(self.path)
        p, q = u.path, parse_qs(u.query)

        if p == "/api/health":
            return self._json(200, {"ok": True, "service": "ApniBari API", "tier": "backend",
                                    "db": "sqlite", "tokens": DB.token_count()})

        if p == "/api/docs":
            return self._json(200, {"ok": True, "service": "ApniBari API",
                                    "version": "2.0", "db": "sqlite", "endpoints": DOCS})

        if p == "/api/pincodes":
            return self._json(200, {"ok": True, "pincodes": D.PINCODES,
                                    "centre": D.CENTRE})

        if p == "/api/hospitals":
            with S.LOCK:
                rec = S.hamdard_recommend(D.CENTRE)
                rec_id = rec["id"] if rec else None
                out = [S.hospital_payload(h, D.CENTRE, rec_id) for h in D.HOSPITALS]
            return self._json(200, {"ok": True, "hospitals": out, "recommendedId": rec_id,
                                    "minutesPerToken": S.MINUTES_PER_TOKEN})

        if p == "/api/nearby":
            pin = "".join(c for c in str((q.get("pin") or [""])[0]) if c.isdigit())[:6]
            if len(pin) != 6:
                return self._json(400, {"ok": False, "error": "pin must be 6 digits"})
            pinrec = S.lookup_pin(pin)
            with S.LOCK:
                if pinrec:
                    rec = S.hamdard_recommend(pinrec)
                    rec_id = rec["id"] if rec else None
                    hospitals = sorted(
                        (S.hospital_payload(h, pinrec, rec_id) for h in D.HOSPITALS),
                        key=lambda x: (x["distKm"] + x["queue"] * 0.1))
                    resp = {"ok": True, "matched": True, "pin": pin,
                            "area": pinrec["area"], "lat": pinrec["lat"], "lng": pinrec["lng"],
                            "hospitals": hospitals, "recommendedId": rec_id,
                            "minutesPerToken": S.MINUTES_PER_TOKEN}
                else:
                    # outside demo dataset — rank by load, no distance claim
                    base = [S.hospital_payload(h, D.CENTRE, None) for h in D.HOSPITALS]
                    base.sort(key=lambda x: x["queue"])
                    for b in base:
                        b["distKm"] = None
                        b["travelMin"] = None
                        b["recommended"] = False
                    resp = {"ok": True, "matched": False, "pin": pin,
                            "area": None,
                            "message": "PIN outside demo service area (Patna district) — ranked by live queue",
                            "hospitals": base, "recommendedId": base[0]["id"] if base else None,
                            "minutesPerToken": S.MINUTES_PER_TOKEN}
            return self._json(200, resp)

        if p == "/api/doctors":
            try:
                hid = int((q.get("h") or ["0"])[0])
            except ValueError:
                hid = 0
            h = S.hosp(hid)
            if not h:
                return self._json(404, {"ok": False, "error": "hospital not found"})
            docs = D.DOCTORS.get(hid, [])
            return self._json(200, {"ok": True,
                                    "hospital": {"id": hid, "nameEn": h["nameEn"]},
                                    "doctors": docs, "onDutyCount": sum(1 for x in docs if x["onDuty"])})

        if p == "/api/state":
            try:
                hid = int((q.get("h") or ["3"])[0])
            except ValueError:
                hid = 3
            h = S.hosp(hid)
            if not h:
                return self._json(404, {"ok": False, "error": "hospital not found"})
            with S.LOCK:
                pend = S.pending(hid)
                lc = S.latest_called(hid)
                up_next = [S.token_code(t["number"]) for t in pend[:5]]
                me = None
                if q.get("number"):
                    try:
                        mynum = int(q["number"][0])
                        row = DB.token_row(hid, mynum)
                        if row:
                            ahead = sum(1 for t in pend if t["number"] < mynum)
                            me = {"number": mynum, "code": S.token_code(mynum),
                                  "status": row["status"], "ahead": ahead,
                                  "etaMin": ahead * S.MINUTES_PER_TOKEN,
                                  "counter": row.get("counter") or 3}
                    except ValueError:
                        pass
                served = S.served_today(hid)
            return self._json(200, {
                "ok": True,
                "hospital": {"id": h["id"], "nameEn": h["nameEn"], "nameHi": h["nameHi"],
                             "timing": h["timing"]},
                "nowServing": S.token_code(lc["number"]) if lc else None,
                "nowServingNum": lc["number"] if lc else None,
                "nowServingCounter": (lc.get("counter") or 3) if lc else None,
                "pending": len(pend), "upNext": up_next,
                "avgWaitMin": len(pend) * S.MINUTES_PER_TOKEN,
                "servedToday": served,
                "me": me,
            })

        if p == "/api/stats":
            with S.LOCK:
                st = DB.stats(_day_start())
            st["minutesPerToken"] = S.MINUTES_PER_TOKEN
            return self._json(200, {"ok": True, **st})

        if p == "/api/call-log":
            try:
                hid = int((q.get("h") or ["0"])[0]) or None
            except ValueError:
                hid = None
            try:
                limit = max(1, min(100, int((q.get("limit") or ["20"])[0])))
            except ValueError:
                limit = 20
            rows = DB.call_log(hid, limit)
            return self._json(200, {"ok": True, "entries": rows})

        return self._json(404, {"ok": False, "error": "unknown api"})

    def do_POST(self):
        p = urlparse(self.path).path
        b = self._body()

        if p == "/api/token":
            try:
                hid = int(b.get("hospitalId") or 3)
            except (ValueError, TypeError):
                hid = 3
            h = S.hosp(hid)
            if not h:
                return self._json(404, {"ok": False, "error": "hospital not found"})
            name = str(b.get("name") or "Patient").strip()[:40] or "Patient"
            phone = "".join(c for c in str(b.get("phone") or "") if c.isdigit())[:10]
            with S.LOCK:
                tok, ahead = S.create_token(hid, name, phone, bool(b.get("pmjay", False)))
            return self._json(200, {"ok": True, "token": tok,
                                    "ahead": ahead, "etaMin": ahead * S.MINUTES_PER_TOKEN,
                                    "hospital": h["nameEn"]})

        if p == "/api/call-next":
            try:
                hid = int(b.get("hospitalId") or 3)
            except (ValueError, TypeError):
                hid = 3
            h = S.hosp(hid)
            if not h:
                return self._json(404, {"ok": False, "error": "hospital not found"})
            with S.LOCK:
                nxt = S.call_next(hid)
            if not nxt:
                return self._json(200, {"ok": False, "message": "No patient waiting"})
            return self._json(200, {"ok": True, "number": nxt["number"],
                                    "code": S.token_code(nxt["number"]), "name": nxt["name"],
                                    "counter": nxt.get("counter") or 1})

        if p == "/api/noshow":
            try:
                hid = int(b.get("hospitalId") or 3)
            except (ValueError, TypeError):
                hid = 3
            with S.LOCK:
                marked = S.mark_noshow(hid)
            return self._json(200, {"ok": True, "marked": marked})

        if p == "/api/doctors/duty":
            try:
                did = int(b.get("doctorId") or 0)
            except (ValueError, TypeError):
                did = 0
            if not did:
                return self._json(400, {"ok": False, "error": "doctorId required"})
            hid = S.set_doctor_duty(did, bool(b.get("onDuty", True)))
            if hid is None:
                return self._json(404, {"ok": False, "error": "doctor not found"})
            docs = D.DOCTORS.get(hid, [])
            return self._json(200, {"ok": True, "doctorId": did,
                                    "onDuty": bool(b.get("onDuty", True)),
                                    "hospitalId": hid,
                                    "onDutyCount": sum(1 for x in docs if x["onDuty"])})

        if p == "/api/staff/login":
            pin = str(b.get("pin") or "")
            if pin.strip() == STAFF_PIN:
                return self._json(200, {"ok": True, "role": "staff",
                                        "token": "sbx-" + secrets.token_hex(8),
                                        "note": "demo session — real build issues a signed JWT"})
            return self._json(401, {"ok": False, "error": "wrong PIN"})

        if p == "/api/seed":
            try:
                hid = int(b.get("hospitalId")) if b.get("hospitalId") else None
            except (ValueError, TypeError):
                hid = None
            count = 40 if hid else 10
            try:
                count = max(1, min(120, int(b.get("count") or count)))
            except (ValueError, TypeError):
                pass
            targets = [S.hosp(hid)] if hid and S.hosp(hid) else D.HOSPITALS
            rng = random.Random(time.time())
            with S.LOCK:
                added = sum(S.seed_tokens(h["id"], count if hid else 10, rng) for h in targets)
            return self._json(200, {"ok": True, "added": added})

        if p == "/api/reset":
            try:
                hid = int(b.get("hospitalId")) if b.get("hospitalId") else None
            except (ValueError, TypeError):
                hid = None
            with S.LOCK:
                removed = S.reset_tokens(hid)
            return self._json(200, {"ok": True, "removed": removed})

        if p == "/api/pmjay":
            digits = str(b.get("digits") or "")
            eligible = S.check_pmjay(digits)
            return self._json(200, {
                "ok": True, "eligible": eligible,
                "coverage": {"familyPerYear": "₹5,00,000", "includes":
                             ["Surgery & hospitalisation", "Medicines & diagnostics",
                              "Food during stay", "Pre & post hospitalisation"]}})

        return self._json(404, {"ok": False, "error": "unknown api"})


class ApiServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


def serve(port=None):
    port = port or PORT
    httpd = ApiServer(("0.0.0.0", port), ApiHandler)
    print(f"  [backend ] ApniBari JSON API + SQLite → http://0.0.0.0:{port}  (tier 2)", flush=True)
    httpd.serve_forever()


if __name__ == "__main__":
    print(f"""
  🟠 ApniBari backend — JSON API + SQLite (no UI here)
     Health : http://localhost:{PORT}/api/health
     Nearby : http://localhost:{PORT}/api/nearby?pin=800020
     Stats  : http://localhost:{PORT}/api/stats
""", flush=True)
    try:
        serve()
    except OSError:
        print(f"Port {PORT} already in use — backend not started.", flush=True)
