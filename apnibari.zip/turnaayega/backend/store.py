# ============================================================
#  ApniBari backend — domain logic over the SQLite store
#  Tokens, live queue, haversine distance, Hamdard recommender.
#  Zero dependencies. All state lives in apnibari.db (db.py);
#  reference data is loaded FROM the database at startup.
# ============================================================

import math
import random
import threading
import time

import data as D
import db as DB

MINUTES_PER_TOKEN = 4          # avg OPD consult → ETA maths
AUTO_MIN_PER_KM = 3.0          # ~20 km/h auto-rickshaw + buffer

LOCK = threading.Lock()

# ---------- bootstrap: create DB, seed + sync reference data ----------
DB.init()
D.HOSPITALS[:] = DB.load_hospitals()          # in-place: every reader sees the DB
D.PINCODES[:] = DB.load_pincodes()
_synced = DB.load_doctors()
D.DOCTORS.clear()
D.DOCTORS.update(_synced)


def refresh_reference(hid=None):
    """Re-read reference rows after an admin mutation (e.g. duty toggle)."""
    if hid is None:
        D.HOSPITALS[:] = DB.load_hospitals()
        D.PINCODES[:] = DB.load_pincodes()
        docs = DB.load_doctors()
        D.DOCTORS.clear()
        D.DOCTORS.update(docs)
    else:
        D.DOCTORS[hid] = DB.load_doctors_one(hid)


# ---------- lookups ----------
def hosp(hid):
    return next((h for h in D.HOSPITALS if h["id"] == hid), None)


def pending(hid):
    return DB.pending(hid)


def latest_called(hid):
    return DB.latest_called(hid)


def next_number(hid):
    con = DB.connect()
    row = con.execute("SELECT MAX(number) m FROM tokens WHERE hospitalId=?",
                      (hid,)).fetchone()
    con.close()
    return (row["m"] or 0) + 1


def token_code(n):
    return "T-" + str(n).zfill(3)


# ---------- geo (the "precise locator") ----------
def haversine_km(lat1, lng1, lat2, lng2):
    """Great-circle distance in km — good to ~0.1 km for district scale."""
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def lookup_pin(pin):
    return next((p for p in D.PINCODES if p["pin"] == pin), None)


def dist_from(h, pinrec):
    return haversine_km(pinrec["lat"], pinrec["lng"], h["lat"], h["lng"])


def live_queue(hid):
    return len(pending(hid)) + hosp(hid)["baseQueue"]


# ---------- Hamdard (हमदर्द) recommender ----------
def hamdard_recommend(pinrec):
    """Nearest + shortest line. score = km + queue*0.1."""
    best, best_score = None, None
    for h in D.HOSPITALS:
        score = dist_from(h, pinrec) + live_queue(h["id"]) * 0.1
        if best_score is None or score < best_score:
            best, best_score = h, score
    return best


# ---------- payload builders ----------
def hospital_payload(h, pinrec, recommended_id):
    q = live_queue(h["id"])
    dist = round(dist_from(h, pinrec), 1) if pinrec else None
    return {
        "id": h["id"], "nameEn": h["nameEn"], "nameHi": h["nameHi"], "type": h["type"],
        "address": h["address"], "timing": h["timing"], "dept": h["dept"], "pmjay": h["pmjay"],
        "lat": h["lat"], "lng": h["lng"],
        "distKm": dist,
        "travelMin": int(round(dist * AUTO_MIN_PER_KM)) if dist is not None else None,
        "queue": q, "etaMin": q * MINUTES_PER_TOKEN,
        "doctors": D.DOCTORS.get(h["id"], []),
        "onDutyCount": sum(1 for doc in D.DOCTORS.get(h["id"], []) if doc["onDuty"]),
        "recommended": h["id"] == recommended_id,
    }


def check_pmjay(digits):
    """DEMO eligibility rule: digit-sum even => covered.
    Real build: ABDM / NPCI sandbox verify."""
    d = [int(c) for c in digits if c.isdigit()]
    return len(d) >= 4 and sum(d) % 2 == 0


# ---------- token lifecycle (SQLite-backed) ----------
def create_token(hid, name, phone, pmjay):
    return DB.create_token(hid, name, phone, pmjay)   # → ({number, code}, ahead)


def call_next(hid):
    return DB.call_next(hid)                          # → token dict or None


def mark_noshow(hid):
    return DB.mark_noshow(hid)                        # → count marked


def seed_tokens(hid, count, rng):
    return DB.seed_tokens(hid, count, rng)


def reset_tokens(hid=None):
    return DB.reset_tokens(hid)


def served_today(hid):
    return DB.served_count(hid)


def set_doctor_duty(doctor_id, on_duty):
    """Admin toggle: update the DB row, then sync the in-memory cache."""
    hid = DB.set_doctor_duty(doctor_id, on_duty)
    if hid is not None:
        refresh_reference(hid)
    return hid
