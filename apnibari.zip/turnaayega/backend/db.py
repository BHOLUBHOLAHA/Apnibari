# ============================================================
#  ApniBari backend — SQLite persistence layer (stdlib sqlite3)
#  The backend now owns a REAL database file: apnibari.db
#
#  tables
#    hospitals / doctors / pincodes   reference data (seeded once)
#    tokens                           one row per missed-call token
#    counters                         last counter number per hospital
#    call_log                         audit trail: token / announce / noshow
#
#  Design: one connection per operation (WAL mode), reference
#  data loaded from the DB at startup so the API never talks to
#  raw SQL outside this module.
# ============================================================

import json
import os
import sqlite3
import time

import data as D

BASE = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE, "apnibari.db")
LEGACY_JSON = os.path.join(BASE, "data.json")   # one-time import source

SCHEMA = """
CREATE TABLE IF NOT EXISTS hospitals (
    id INTEGER PRIMARY KEY, nameEn TEXT, nameHi TEXT, type TEXT,
    lat REAL, lng REAL, address TEXT, timing TEXT, dept TEXT,
    pmjay INTEGER DEFAULT 1, baseQueue INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS doctors (
    id INTEGER PRIMARY KEY AUTOINCREMENT, hospitalId INTEGER REFERENCES hospitals(id),
    name TEXT, dept TEXT, qual TEXT, days TEXT, hours TEXT, room TEXT,
    onDuty INTEGER DEFAULT 1, exp INTEGER DEFAULT 0, langs TEXT);
CREATE TABLE IF NOT EXISTS pincodes (
    pin TEXT PRIMARY KEY, area TEXT, lat REAL, lng REAL);
CREATE TABLE IF NOT EXISTS tokens (
    id INTEGER PRIMARY KEY AUTOINCREMENT, hospitalId INTEGER, number INTEGER,
    name TEXT, phone TEXT, status TEXT DEFAULT 'pending', pmjay INTEGER DEFAULT 0,
    createdAt REAL, calledAt REAL, counter INTEGER);
CREATE INDEX IF NOT EXISTS idx_tokens_h ON tokens(hospitalId, number);
CREATE TABLE IF NOT EXISTS counters (
    hospitalId INTEGER PRIMARY KEY, last INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS call_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, hospitalId INTEGER, code TEXT,
    action TEXT, detail TEXT, ts REAL);
"""


def connect():
    con = sqlite3.connect(DB_FILE, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=8000")
    con.execute("PRAGMA foreign_keys=ON")
    return con


# ---------- bootstrap ----------
def init():
    con = connect()
    con.executescript(SCHEMA)
    con.execute("PRAGMA journal_mode=WAL")
    _seed_reference(con)
    _import_legacy_json(con)
    con.commit()
    con.close()


def _seed_reference(con):
    if con.execute("SELECT COUNT(*) c FROM hospitals").fetchone()["c"] == 0:
        for h in D.HOSPITALS:
            con.execute(
                "INSERT INTO hospitals VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                (h["id"], h["nameEn"], h["nameHi"], h["type"], h["lat"], h["lng"],
                 h["address"], h["timing"], h["dept"], int(h["pmjay"]), h["baseQueue"]))
    if con.execute("SELECT COUNT(*) c FROM doctors").fetchone()["c"] == 0:
        for hid, docs in D.DOCTORS.items():
            for d in docs:
                con.execute(
                    "INSERT INTO doctors (hospitalId,name,dept,qual,days,hours,room,"
                    "onDuty,exp,langs) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (hid, d["name"], d["dept"], d["qual"], d["days"], d["hours"],
                     d["room"], int(d["onDuty"]), d["exp"], d["langs"]))
    if con.execute("SELECT COUNT(*) c FROM pincodes").fetchone()["c"] == 0:
        for p in D.PINCODES:
            con.execute("INSERT INTO pincodes VALUES (?,?,?,?)",
                        (p["pin"], p["area"], p["lat"], p["lng"]))


def _import_legacy_json(con):
    """One-time migration of the old data.json token store."""
    if con.execute("SELECT COUNT(*) c FROM tokens").fetchone()["c"] > 0:
        return
    try:
        with open(LEGACY_JSON, "r", encoding="utf-8") as f:
            old = json.load(f)
        n = 0
        for t in old.get("tokens", []):
            con.execute(
                "INSERT INTO tokens (hospitalId,number,name,phone,status,pmjay,"
                "createdAt,calledAt,counter) VALUES (?,?,?,?,?,?,?,?,?)",
                (t["hospitalId"], t["number"], t.get("name", "Patient"),
                 t.get("phone", ""), t.get("status", "pending"),
                 int(bool(t.get("pmjay"))), t.get("createdAt") or time.time(),
                 t.get("calledAt"), t.get("counter")))
            n += 1
        for hid, last in (old.get("counters") or {}).items():
            con.execute("INSERT OR REPLACE INTO counters VALUES (?,?)",
                        (int(hid), int(last)))
        if n:
            con.execute("INSERT INTO call_log (hospitalId,code,action,detail,ts) "
                        "VALUES (0,'—','migrate',?,?)",
                        (f"imported {n} tokens from data.json", time.time()))
    except Exception:
        pass   # fresh install without a legacy file — nothing to import


# ---------- reference data (loaded into memory by store.py) ----------
def load_hospitals():
    con = connect()
    rows = con.execute("SELECT * FROM hospitals ORDER BY id").fetchall()
    con.close()
    return [{"id": r["id"], "nameEn": r["nameEn"], "nameHi": r["nameHi"],
             "type": r["type"], "lat": r["lat"], "lng": r["lng"],
             "address": r["address"], "timing": r["timing"], "dept": r["dept"],
             "pmjay": bool(r["pmjay"]), "baseQueue": r["baseQueue"]} for r in rows]


def load_doctors():
    con = connect()
    rows = con.execute("SELECT * FROM doctors ORDER BY hospitalId, id").fetchall()
    con.close()
    out = {}
    for r in rows:
        out.setdefault(r["hospitalId"], []).append(
            {"name": r["name"], "dept": r["dept"], "qual": r["qual"],
             "days": r["days"], "hours": r["hours"], "room": r["room"],
             "onDuty": bool(r["onDuty"]), "exp": r["exp"], "langs": r["langs"]})
    return out


def load_pincodes():
    con = connect()
    rows = con.execute("SELECT * FROM pincodes ORDER BY pin").fetchall()
    con.close()
    return [{"pin": r["pin"], "area": r["area"], "lat": r["lat"], "lng": r["lng"]}
            for r in rows]


def set_doctor_duty(doctor_id, on_duty):
    """Ward-admin toggle: mark a doctor on/off duty. Returns hospitalId or None."""
    con = connect()
    cur = con.execute("UPDATE doctors SET onDuty=? WHERE id=?",
                      (int(bool(on_duty)), doctor_id))
    con.commit()
    hid = None
    if cur.rowcount:
        row = con.execute("SELECT hospitalId FROM doctors WHERE id=?",
                          (doctor_id,)).fetchone()
        hid = row["hospitalId"] if row else None
    con.close()
    return hid


def load_doctors_one(hid):
    con = connect()
    rows = con.execute("SELECT * FROM doctors WHERE hospitalId=? ORDER BY id",
                       (hid,)).fetchall()
    con.close()
    return [{"name": r["name"], "dept": r["dept"], "qual": r["qual"],
             "days": r["days"], "hours": r["hours"], "room": r["room"],
             "onDuty": bool(r["onDuty"]), "exp": r["exp"], "langs": r["langs"]}
            for r in rows]


# ---------- token lifecycle ----------
def _row_to_token(r):
    return {"hospitalId": r["hospitalId"], "number": r["number"], "name": r["name"],
            "phone": r["phone"] or "", "status": r["status"],
            "pmjay": bool(r["pmjay"]), "createdAt": r["createdAt"],
            "calledAt": r["calledAt"], "counter": r["counter"]}


def create_token(hid, name, phone, pmjay):
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    row = con.execute("SELECT MAX(number) m FROM tokens WHERE hospitalId=?",
                      (hid,)).fetchone()
    num = (row["m"] or 0) + 1
    now = time.time()
    con.execute("INSERT INTO tokens (hospitalId,number,name,phone,status,pmjay,"
                "createdAt,calledAt) VALUES (?,?,?,?,'pending',?,?,NULL)",
                (hid, num, name, phone, int(bool(pmjay)), now))
    code = "T-" + str(num).zfill(3)
    con.execute("INSERT INTO call_log (hospitalId,code,action,detail,ts) "
                "VALUES (?,?,'token',?,?)", (hid, code, f"{name} registered", now))
    ahead = con.execute(
        "SELECT COUNT(*) c FROM tokens WHERE hospitalId=? AND status='pending' "
        "AND number<?", (hid, num)).fetchone()["c"]
    con.commit()
    con.close()
    return {"number": num, "code": code}, ahead


def pending(hid):
    con = connect()
    rows = con.execute("SELECT * FROM tokens WHERE hospitalId=? AND status='pending' "
                       "ORDER BY number", (hid,)).fetchall()
    con.close()
    return [_row_to_token(r) for r in rows]


def latest_called(hid):
    con = connect()
    row = con.execute("SELECT * FROM tokens WHERE hospitalId=? AND status='called' "
                      "ORDER BY calledAt DESC, number DESC LIMIT 1", (hid,)).fetchone()
    con.close()
    return _row_to_token(row) if row else None


def token_row(hid, number):
    con = connect()
    row = con.execute("SELECT * FROM tokens WHERE hospitalId=? AND number=?",
                      (hid, number)).fetchone()
    con.close()
    return _row_to_token(row) if row else None


def served_count(hid):
    con = connect()
    n = con.execute("SELECT COUNT(*) c FROM tokens WHERE hospitalId=? AND "
                    "status IN ('done','called')", (hid,)).fetchone()["c"]
    con.close()
    return n


def call_next(hid):
    """Finish the previous announcement, call the first pending token.
    Counter rotates 1→2→3→1 per hospital. Returns the token dict or None."""
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    con.execute("UPDATE tokens SET status='done' WHERE hospitalId=? AND "
                "status='called'", (hid,))
    row = con.execute("SELECT * FROM tokens WHERE hospitalId=? AND status='pending' "
                      "ORDER BY number LIMIT 1", (hid,)).fetchone()
    if not row:
        con.commit()
        con.close()
        return None
    last = con.execute("SELECT last FROM counters WHERE hospitalId=?",
                       (hid,)).fetchone()
    counter = ((last["last"] if last else 0) % 3) + 1
    now = time.time()
    con.execute("UPDATE tokens SET status='called', calledAt=?, counter=? WHERE id=?",
                (now, counter, row["id"]))
    con.execute("INSERT INTO counters VALUES (?,?) "
                "ON CONFLICT(hospitalId) DO UPDATE SET last=excluded.last", (hid, counter))
    code = "T-" + str(row["number"]).zfill(3)
    con.execute("INSERT INTO call_log (hospitalId,code,action,detail,ts) "
                "VALUES (?,?,'announce',?,?)",
                (hid, code, f"{row['name']} → counter {counter}", now))
    con.commit()
    con.close()
    return _row_to_token(row) | {"counter": counter, "status": "called"}


def mark_noshow(hid):
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    rows = con.execute("SELECT number,name FROM tokens WHERE hospitalId=? AND "
                       "status='called'", (hid,)).fetchall()
    now = time.time()
    con.execute("UPDATE tokens SET status='noshow' WHERE hospitalId=? AND "
                "status='called'", (hid,))
    for r in rows:
        con.execute("INSERT INTO call_log (hospitalId,code,action,detail,ts) "
                    "VALUES (?,?,'noshow',?,?)",
                    (hid, "T-" + str(r["number"]).zfill(3),
                     f"{r['name']} marked absent", now))
    con.commit()
    con.close()
    return len(rows)


def seed_tokens(hid, count, rng):
    """Demo-fill: bulk-insert pending tokens (kept JSON-free)."""
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    row = con.execute("SELECT MAX(number) m FROM tokens WHERE hospitalId=?",
                      (hid,)).fetchone()
    num = row["m"] or 0
    now = time.time()
    for _ in range(count):
        num += 1
        con.execute("INSERT INTO tokens (hospitalId,number,name,phone,status,pmjay,"
                    "createdAt,calledAt) VALUES (?,?,?,?,'pending',?,?,NULL)",
                    (hid, num, rng.choice(D.SEED_NAMES),
                     "9" + str(rng.randint(100000000, 999999999)),
                     int(rng.random() < 0.6), now))
    con.commit()
    con.close()
    return count


def reset_tokens(hid=None):
    con = connect()
    con.execute("BEGIN IMMEDIATE")
    if hid is None:
        before = con.execute("SELECT COUNT(*) c FROM tokens").fetchone()["c"]
        con.execute("DELETE FROM tokens")
        con.execute("DELETE FROM counters")
    else:
        before = con.execute("SELECT COUNT(*) c FROM tokens WHERE hospitalId=?",
                             (hid,)).fetchone()["c"]
        con.execute("DELETE FROM tokens WHERE hospitalId=?", (hid,))
        con.execute("DELETE FROM counters WHERE hospitalId=?", (hid,))
    con.execute("INSERT INTO call_log (hospitalId,code,action,detail,ts) "
                "VALUES (?,?, 'reset', ?, ?)",
                (hid or 0, "—", f"queue cleared ({before} tokens)", time.time()))
    con.commit()
    con.close()
    return before


# ---------- analytics & audit ----------
def stats(day_start):
    """Today-at-a-glance numbers for the admin dashboard."""
    con = connect()
    q = con.execute
    total = q("SELECT COUNT(*) c FROM tokens WHERE createdAt>=?", (day_start,)).fetchone()["c"]
    served = q("SELECT COUNT(*) c FROM tokens WHERE status='done' AND calledAt>=?",
               (day_start,)).fetchone()["c"]
    waiting = q("SELECT COUNT(*) c FROM tokens WHERE status='pending'").fetchone()["c"]
    noshow = q("SELECT COUNT(*) c FROM tokens WHERE status='noshow' AND calledAt>=?",
               (day_start,)).fetchone()["c"]
    per = q("SELECT hospitalId, COUNT(*) issued, "
            "SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) done, "
            "SUM(CASE WHEN status='pending' THEN 1 ELSE 0 END) waiting, "
            "SUM(CASE WHEN status='noshow' THEN 1 ELSE 0 END) noshow "
            "FROM tokens WHERE createdAt>=? GROUP BY hospitalId",
            (day_start,)).fetchall()
    announcements = q("SELECT COUNT(*) c FROM call_log WHERE action='announce' AND ts>=?",
                      (day_start,)).fetchone()["c"]
    con.close()
    return {"tokensToday": total, "servedToday": served, "waitingNow": waiting,
            "noShowToday": noshow, "announcementsToday": announcements,
            "byHospital": {str(r["hospitalId"]): {"issued": r["issued"],
                                                  "done": r["done"] or 0,
                                                  "waiting": r["waiting"] or 0,
                                                  "noshow": r["noshow"] or 0}
                           for r in per}}


def call_log(hid=None, limit=20):
    con = connect()
    if hid is None:
        rows = con.execute("SELECT * FROM call_log ORDER BY id DESC LIMIT ?",
                           (limit,)).fetchall()
    else:
        rows = con.execute("SELECT * FROM call_log WHERE hospitalId=? "
                           "ORDER BY id DESC LIMIT ?", (hid, limit)).fetchall()
    con.close()
    return [{"hospitalId": r["hospitalId"], "code": r["code"], "action": r["action"],
             "detail": r["detail"], "ts": r["ts"]} for r in rows]


def token_count():
    con = connect()
    n = con.execute("SELECT COUNT(*) c FROM tokens").fetchone()["c"]
    con.close()
    return n
