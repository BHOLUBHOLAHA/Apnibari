# 🟢 ApniBari (अपनी बारी) — Your Turn. Without the Wait.

**Missed-call virtual OPD queue for Indian government hospitals.**
Enter your **PIN code** → see the nearest government hospitals with **live doctor rosters** →
give a **missed call** → AI calls back in Hindi with a token → wait at home → the ward TV
announces **"बारी आ गई!"**.

Built with **pure Python + HTML + CSS + JavaScript — zero dependencies**,
in a **clean two-tier architecture** (frontend ⟷ backend over HTTP only).

---

## 🏗 Architecture — frontend and backend are separate

```
┌──────────────────────────────┐            ┌──────────────────────────────┐
│  FRONTEND  (tier 1)  :3000   │            │  BACKEND  (tier 2)   :8001   │
│  frontend/server.py          │   HTTP     │  backend/app.py              │
│  ──────────────────────────  │  ────────▶ │  ──────────────────────────  │
│  static HTML/CSS/JS          │  /api/*    │  JSON API only — no UI       │
│  (pure UI, no logic)         │  proxied   │  store.py (queue, haversine, │
│  + thin /api proxy           │            │           Hamdard, PM-JAY)   │
│                              │            │  db.py    → SQLite (WAL)     │
│                              │            │  apnibari.db — tokens,       │
│                              │            │  doctors, PINs, call audit   │
└──────────────────────────────┘            └──────────────────────────────┘
```

- The UI contains **zero business logic** — it only `fetch()`es JSON.
- The backend contains **zero UI** — it only speaks JSON (CORS open, consumable from anywhere).
- The backend owns a **real SQLite database** (`backend/apnibari.db`, WAL mode, zero
  dependencies — `sqlite3` is stdlib): reference tables for hospitals/doctors/PIN zones,
  plus `tokens`, `counters` and a full **call audit trail** (`token → announce → noshow`).
- Each tier **runs standalone**: `python3 backend/app.py` / `python3 frontend/server.py`.
- The frontend proxy mirrors production practice (nginx ⟶ API service).

## 🚀 Run it

```bash
python3 start.py          # starts BOTH tiers, prints all URLs
```

| Page | URL | What it is |
|---|---|---|
| **Landing** | `http://localhost:3000/` | Pitch site + PIN quick-find box |
| **Patient Demo** | `http://localhost:3000/demo` | PIN locator → doctors → missed call → token |
| **Hospital TV** | `http://localhost:3000/tv` | Now-Serving board + Hindi voice |
| **Backend API Console** | `http://localhost:3000/console` | Open the backend in the browser: try all 17 endpoints live + happy-path runner |
| **Raw API** | `http://localhost:8001/api/health` | Backend direct (no UI) |

> Custom ports: `PORT=8080 BACKEND_PORT=9001 python3 start.py`

## 📌 The PIN code locator (precise, not fake)

Patient types a 6-digit PIN → backend matches it against the **Patna district PIN-zone
dataset** (15 zones, India Post centroids) → computes **haversine distance** to every
hospital → returns hospitals **sorted nearest-first** with:
- distance in km + auto-rickshaw travel estimate
- live queue length + ETA (4 min/token)
- **doctor roster**: name, specialty, qualification, experience, OPD days/hours, room,
  languages, and who is **on duty today**
- 🤖 **Hamdard pick** = best score of `distance + queue×0.1`

Try: `800020` (Kankarbagh) · `800001` (Patna City) · `803213` (Barh) · `801503` (Danapur).
Unknown PINs get an honest "outside demo service area" response — ranked by live queue.

## 🔌 API contract (backend tier, :8001)

| Method | Endpoint | Returns |
|---|---|---|
| GET | `/api/health` | liveness |
| GET | `/api/pincodes` | searchable PIN zones |
| GET | `/api/nearby?pin=800020` | hospitals sorted by distance + doctors + Hamdard pick |
| GET | `/api/hospitals` | hospital list + live queue |
| GET | `/api/doctors?h=3` | doctor roster for one hospital |
| GET | `/api/state?h=&number=` | now serving, up-next, "my token" tracker |
| GET | `/api/stats` | today-at-a-glance: issued / served / waiting / no-show |
| GET | `/api/call-log?h=&limit=` | audit trail from the DB (token / announce / noshow) |
| GET | `/api/docs` | self-documenting endpoint catalog |
| POST | `/api/token` | register missed-call token |
| POST | `/api/call-next` | staff: announce next (rotates counters 1-3) |
| POST | `/api/noshow` | staff: mark called patient absent |
| POST | `/api/doctors/duty` | admin: toggle a doctor on/off duty (persists in DB) |
| POST | `/api/staff/login` | staff PIN `2026` → demo session token |
| POST | `/api/seed` · `/api/reset` | demo-fill / clear queue |
| POST | `/api/pmjay` | eligibility check (demo rule: digit-sum even) |

## 🎬 60-second demo script (for judges)

1. On the landing hero type PIN **800020** → **Find** → demo opens pre-located.
2. Expand **👨‍⚕️ doctors** on any hospital — show who's on duty right now.
3. Pick the 🤖 Hamdard hospital → name + number → **📞 Give Missed Call** → Hindi IVR → token.
4. 💙 PM-JAY check with `4321` → free-treatment eligibility.
5. Open **`/tv`** in a second tab → **🔔 Call Next** → board flashes the token, Hindi voice
   announces. Back on `/demo` the patient card already says **"बारी आ गई! Counter N"**.
6. Prove the backend is real: `curl localhost:8001/api/stats` and `/api/call-log` — every
   step of the journey is a row in **SQLite** (`backend/apnibari.db`).

Staff controls on TV: `Call Next` · `No-show` · `Demo-fill 40` · `Reset` · `Voice on/off` ·
`Hide (H)` · `N` key = call next.

## 📁 Project layout

```
turnaayega/
├── start.py                 # one command → both tiers
├── backend/                 # TIER 2 — no UI, owns the database
│   ├── app.py               #   JSON API server (:8001) + route table
│   ├── store.py             #   domain logic: queue, haversine, Hamdard, PM-JAY
│   ├── db.py                #   SQLite layer (WAL) — schema, seeds, migration
│   ├── apnibari.db          #   THE database (auto-created; ships empty)
│   └── data.py              #   seed datasets (hospitals, doctors, PIN zones)
└── frontend/                # TIER 1 — no business logic
    ├── server.py            #   static server (:3000) + /api proxy
    └── static/              #   index.html · demo.html · tv.html
        ├── css/style.css    #   design system
        ├── js/              #   app.js · demo.js · tv.js
        └── img/             #   logo + illustrations
```

### 🗄 Database schema (SQLite, `backend/apnibari.db`)

| Table | Purpose |
|---|---|
| `hospitals` | the 5 facilities (lat/lng power the PIN locator) |
| `doctors` | roster + `onDuty` flag (admin-toggleable via API) |
| `pincodes` | 15 India Post PIN-zone centroids |
| `tokens` | one row per missed call — number, status, counter, timestamps |
| `counters` | last counter served per hospital (1→2→3 rotation) |
| `call_log` | audit trail: `token` / `announce` / `noshow` / `reset` |

## 📝 Data honesty (say this to judges)

PIN zones = India Post centroids for Patna district (approx.). Hospitals & doctors =
demo records. Queue data = live from the demo server, persisted in SQLite. PM-JAY rule =
simulated (real build verifies via ABDM/NPCI sandbox); staff PIN & session token are demo
(real build issues signed JWTs). Scan & Share / PM-JAY statistics on the
landing page are from NHA & PIB (Jul 2025).
